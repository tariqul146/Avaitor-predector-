package com.example.aviatoranalyzer

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.ArrayDeque
import java.util.Locale
import java.util.regex.Pattern

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CHANNEL = "aviator_capture"
        private const val NOTIFICATION_ID = 8801
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val history = ArrayDeque<Double>()
    private var overlay: TextView? = null
    private var busy = false
    private var lastText = ""
    private val regex = Pattern.compile("(?<![0-9])([0-9]{1,3}(?:\\.[0-9]{1,2})?)\\s*[xX]")

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        addOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (code != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, handler)
            val metrics = resources.displayMetrics
            val w = metrics.widthPixels
            val h = metrics.heightPixels
            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            display = projection?.createVirtualDisplay(
                "AviatorScreenReader", w, h, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, handler
            )
            handler.post(captureLoop)
            setOverlayText("88FB Analyzer\nস্ক্রিন পড়া হচ্ছে…\nHistory আসলে ফলাফল দেখাবে")
        } catch (e: Exception) {
            setOverlayText("Capture চালু হয়নি: ${e.message}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private val captureLoop = object : Runnable {
        override fun run() {
            if (!busy) {
                val image = reader?.acquireLatestImage()
                if (image != null) processImage(image)
            }
            handler.postDelayed(this, 1100)
        }
    }

    private fun processImage(image: Image) {
        busy = true
        try {
            val bitmap = imageToBitmap(image)
            image.close()
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { result ->
                    val text = result.text
                    if (text != lastText) {
                        lastText = text
                        parseText(text)
                    }
                }
                .addOnFailureListener { setOverlayText("OCR পড়তে পারেনি। স্ক্রিন পরিষ্কার রাখুন।") }
                .addOnCompleteListener { bitmap.recycle(); busy = false }
        } catch (e: Exception) {
            try { image.close() } catch (_: Exception) {}
            busy = false
        }
    }

    private fun imageToBitmap(image: Image): android.graphics.Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val padded = android.graphics.Bitmap.createBitmap(paddedWidth, image.height, android.graphics.Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        val cropped = android.graphics.Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun parseText(text: String) {
        val matcher = regex.matcher(text)
        val found = mutableListOf<Double>()
        while (matcher.find()) {
            val v = matcher.group(1)?.toDoubleOrNull() ?: continue
            if (v >= 1.0 && v <= 1000.0) found.add(v)
        }
        // OCR text is scanned as a whole screen. Add only a newly observed tail value,
        // avoiding repeated insertion of the same visible history on every frame.
        val unique = found.distinct()
        if (unique.isNotEmpty()) {
            val newest = unique.last()
            if (history.peekLast() != newest) {
                history.addLast(newest)
                while (history.size > 100) history.removeFirst()
            }
        }
        val values = history.toList()
        val p15 = if (values.isEmpty()) 0 else values.count { it >= 1.5 } * 100 / values.size
        val p20 = if (values.isEmpty()) 0 else values.count { it >= 2.0 } * 100 / values.size
        val p50 = if (values.isEmpty()) 0 else values.count { it >= 5.0 } * 100 / values.size
        val recent = values.takeLast(12).joinToString("  ") { String.format(Locale.US, "%.2fx", it) }
        val display = if (values.isEmpty()) {
            "88FB Analyzer\nHistory multiplier পাওয়া যায়নি\nAviator Round History খুলুন"
        } else {
            "88FB Analyzer  •  OCR live\nSample: ${values.size} rounds\nEmpirical ≥1.5x: $p15%   ≥2x: $p20%   ≥5x: $p50%\nশেষ পড়া: $recent\nএগুলো অতীতের হার, পরের রাউন্ডের prediction নয়।"
        }
        setOverlayText(display)
    }

    private fun addOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            text = "88FB Analyzer\nScreen capture অনুমতির অপেক্ষায়"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xDD171717.toInt())
            setPadding(18, 14, 18, 14)
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 120 }
        try { wm.addView(overlay, params) } catch (_: Exception) {}
    }

    private fun setOverlayText(value: String) {
        handler.post { overlay?.text = value }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Aviator screen analysis", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val launch = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
            .setContentTitle("88FB Analyzer is running")
            .setContentText("Screen text is being analyzed locally")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(launch).build()
        else Notification.Builder(this).setContentTitle("88FB Analyzer")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
    }

    override fun onDestroy() {
        handler.removeCallbacks(captureLoop)
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { recognizer.close() } catch (_: Exception) {}
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            overlay?.let { wm.removeView(it) }
        } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}

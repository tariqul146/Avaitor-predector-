package com.example.aviatoranalyzer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val captureRequest = 4102
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        val title = TextView(this).apply {
            text = "88FB Aviator Analyzer"
            textSize = 24f
        }
        status = TextView(this).apply {
            textSize = 16f
            text = "শুরু করতে Overlay permission দিন, তারপর Screen Capture চালু করুন।"
            setPadding(0, 24, 0, 24)
        }
        val overlay = Button(this).apply {
            text = "1. Allow Floating Overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else status.text = "Overlay permission দেওয়া আছে।"
            }
        }
        val start = Button(this).apply {
            text = "2. Start Screen Analyzer"
            setOnClickListener { requestCapture() }
        }
        val stop = Button(this).apply {
            text = "Stop Analyzer"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "Analyzer বন্ধ করা হয়েছে।"
            }
        }
        layout.addView(title); layout.addView(status)
        layout.addView(overlay); layout.addView(start); layout.addView(stop)
        setContentView(layout)
    }

    private fun requestCapture() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "আগে Floating Overlay permission দিন।"
            return
        }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Legacy callback is used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            status.text = "Screen Analyzer চালু হয়েছে। 88FB Aviator স্ক্রিনে যান।"
        } else {
            status.text = "Screen Capture অনুমতি দেওয়া হয়নি।"
        }
    }
}

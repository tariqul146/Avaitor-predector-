# 88FB Aviator Analyzer — Android source project

এটি একটি **source project**, ইনস্টল করার মতো APK নয়। Android Studio দিয়ে APK build করতে হবে।

## কী আছে
- Android MediaProjection দিয়ে user-consented screen capture
- ML Kit OCR দিয়ে স্ক্রিনে দৃশ্যমান `1.23x`-জাতীয় multiplier পড়ার চেষ্টা
- Floating overlay
- OCR-এ ধরা নমুনার মধ্যে 1.5x / 2x / 5x বা তার বেশি হওয়া রাউন্ডের empirical frequency

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই অ্যাপ 88FB-এর private API, account, password বা server database ব্যবহার করে না।
- OCR কেবল স্ক্রিনে দৃশ্যমান লেখা পড়ে; History popup/round history দৃশ্যমান রাখলে ভালো কাজ করবে।
- বর্তমান implementation একটি prototype: OCR-এর ক্রম/ডুপ্লিকেট শনাক্তকরণ সব layout-এ নির্ভুল নয়; live round-কে round history থেকে আলাদা করার নিশ্চয়তা নেই।
- “Probability” হলো ইতিমধ্যে পড়া নমুনার অতীতের হার। এটি পরবর্তী crash point বা fair seed বের করে না এবং ভবিষ্যৎ ফলের নিশ্চয়তা দেয় না।
- Screen capture চালু থাকলে Android-এর স্থায়ী notification দেখা যাবে। যেকোনো সময় Stop Analyzer চাপুন।
- স্ক্রিনের তথ্য ডিভাইসেই OCR করা হয়; কোনো server-এ পাঠানোর code নেই।

## APK build
1. Android Studio (Hedgehog বা নতুন) ইনস্টল করুন।
2. ZIP extract করে `88fb_aviator_analyzer` folder Android Studio-তে Open করুন।
3. Gradle sync সম্পন্ন হতে দিন (প্রথমবার internet লাগবে dependencies নামাতে)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK পাবেন `app/build/outputs/apk/debug/app-debug.apk`-এ।

## ফোনে চালানো
1. APK install করুন।
2. অ্যাপ খুলে `Allow Floating Overlay` চাপুন এবং permission দিন।
3. `Start Screen Analyzer` চাপুন; Android-এর screen-capture prompt-এ Start now দিন।
4. 88FB-তে Aviator খুলুন এবং Round History দৃশ্যমান রাখুন।
5. Overlay-তে OCR পড়া multiplier ও sample statistics দেখা যাবে।
6. বন্ধ করতে অ্যাপে ফিরে `Stop Analyzer` চাপুন।

## Target
Android 8.0+ (API 26+), compile SDK 35, Java 17 / Android Studio recommended.


## শুধু ফোন দিয়ে GitHub Actions-এ APK build
1. GitHub account খুলুন / sign in করুন: https://github.com
2. `New repository` দিয়ে একটি repository বানান; নাম দিন `88fb-aviator-analyzer`।
3. এই ZIP extract করে সব ফাইল repository-তে upload করুন। `.github/workflows/build-apk.yml` ফাইলটিও upload হয়েছে কি না দেখুন।
4. GitHub repository-তে **Actions** tab খুলুন।
5. `Build 88FB Analyzer APK` workflow নির্বাচন করে **Run workflow** চাপুন।
6. কাজ শেষ হলে workflow run-এর নিচে **Artifacts** থেকে `88fb-aviator-analyzer-debug-apk` ডাউনলোড করুন।
7. ZIP artifact extract করে `app-debug.apk` ফোনে install করুন। Android চাইলে browser/file manager-কে “Install unknown apps” permission দিন।

GitHub Actions build log-এ error হলে APK তৈরি হবে না; error log দেখে source ঠিক করতে হবে. APKটি debug build, Play Store release build নয়.
